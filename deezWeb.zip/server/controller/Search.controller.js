const axios = require("axios");

module.exports.global = async (req, res) => {
  const q = req.query.q;
  const order = req.query.order;

  if (order) {
    const result = await axios.get(
      `https://api.deezer.com/search?q=${q.trim()}&order=${order.trim()}`
    );
    return res.json(result.data);
  } else {
    const result = await axios.get(
      `https://api.deezer.com/search?q=${q.trim()}`
    );
    return res.json(result.data);
  }
};

module.exports.tracks = async (req, res) => {
  const q = req.query.q;
  const order = req.query.order;

  if (order) {
    const result = await axios.get(
      `https://api.deezer.com/search/track?q=${q.trim()}&order=${order.trim()}`
    );
    return res.json(result.data);
  } else {
    const result = await axios.get(
      `https://api.deezer.com/search/track?q=${q.trim()}`
    );
    return res.json(result.data);
  }
};

module.exports.artists = async (req, res) => {
  const q = req.query.q;
  const order = req.query.order;

  if (order) {
    const result = await axios.get(
      `https://api.deezer.com/search/artist?q=${q.trim()}&order=${order.trim()}`
    );
    return res.json(result.data);
  } else {
    const result = await axios.get(
      `https://api.deezer.com/search/artist?q=${q.trim()}`
    );
    return res.json(result.data);
  }
};

module.exports.albums = async (req, res) => {
  const q = req.query.q;
  const order = req.query.order;

  if (order) {
    const result = await axios.get(
      `https://api.deezer.com/search/album?q=${q.trim()}&order=${order.trim()}`
    );
    return res.json(result.data);
  } else {
    const result = await axios.get(
      `https://api.deezer.com/search/album?q=${q.trim()}`
    );
    return res.json(result.data);
  }
};

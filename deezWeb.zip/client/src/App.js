import "./App.css";

import { Routes, Route } from "react-router-dom";
import Home from "./Pages/Home";
import Tracks from "./Pages/Tracks";
import Favoris from "./Pages/Favoris";
import Albums from "./Pages/Albums";
import Artists from "./Pages/Artists";
import MainLayout from "./Components/Themes/MainLayout";
import TrackSelected from "./Pages/Tracks/TrackSelected";
import AlbumSelected from "./Pages/Albums/AlbumSelected";
import ArtistSelected from "./Pages/Artists/ArtistSelected";
import SearchPageResult from "./Pages/SearchPageResult";

import "react-toastify/dist/ReactToastify.css";

function App() {
  return (
    <Routes>
      <Route path="/" element={<MainLayout />}>
        <Route index element={<Home />}></Route>
        <Route path="tracks" element={<Tracks />}></Route>
        <Route path="track/:id" element={<TrackSelected />}></Route>
        <Route path="artists" element={<Artists />}></Route>
        <Route path="artist/:id" element={<ArtistSelected />}></Route>
        <Route path="albums" element={<Albums />}></Route>
        <Route path="album/:id" element={<AlbumSelected />}></Route>
        <Route path="favoris" element={<Favoris />}></Route>
        <Route
          path="/results/:q/:type/:order"
          element={<SearchPageResult />}
        ></Route>
      </Route>
    </Routes>
  );
}

export default App;

import React from "react";
import styled from "styled-components";

const Parent = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-start;
  width: 100%;
  div {
    flex: none;
  }
`;

const RowsFlexWrap = ({ children, ...props }) => {
  return <Parent {...props}> {children} </Parent>;
};

export default RowsFlexWrap;

import React from "react";
import styled from "styled-components";
import { Outlet } from "react-router-dom";
import SideBar from "../SideBar";
import Playerbar from "../PlayerBar";
import BottomNavigation from "../BottomNavigation";
import { ToastContainer } from "react-toastify";

const MainContainer = styled.div`
  display: flex;
  min-height: 100vh;
  max-width: 100%;
  margin: 0 auto;
  position: relative;
  background: linear-gradient(0.33deg, #040c18 24.1%, #031b34 96.92%);
  tansition: all 0.35s;
  overflow-x: hidden;
`;
const LeftSide = styled.div`
  display: none;
  min-height: 100vh;
  position: relative;
  @media screen and (min-width: 550px) {
    width: 250px;
  }
`;
const MiddleSide = styled.div`
  width: 100%;
  min-height: 100vh;
  color: #fff;
  margin-bottom: 180px;
`;

const RightSide = styled.div`
  display: none;
  width: 200px;
  min-height: 100vh;
  position: relative;

  @media screen and (min-width: 550px) {
    width: 200px;
  }
`;

const MainLayout = () => {
  return (
    <MainContainer>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={true}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
      <SideBar />
      <MiddleSide>
        <Outlet />
      </MiddleSide>
      <BottomNavigation />
      <ToastContainer />
    </MainContainer>
  );
};

export default MainLayout;

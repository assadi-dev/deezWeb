import Home from "./Pages/Home";
import Favoris from "./Pages/Favoris";
import Albums from "./Pages/Albums";
import Artists from "./Pages/Artists";

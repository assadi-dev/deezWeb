import React from "react";

const Tracks = () => {
  return (
    <div>
      <h1>Mes tracks</h1>
    </div>
  );
};

export default Tracks;

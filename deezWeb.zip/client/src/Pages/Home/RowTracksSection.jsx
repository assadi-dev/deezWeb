import React, { useEffect, useMemo, useState, usestate } from "react";
import styled from "styled-components";
import { Swiper, SwiperSlide } from "swiper/react";
import TrackCard from "../../Components/TrackCard";

import { findOnePlaylist } from "../../Redux/Actions/playlist.action";
import Api from "../../Services/Api";

export const RowTitle = styled.h2`
  font-size: 32px;
  font-weight: bold;
  margin-top: 13px;
  margin-bottom: 13px;
`;

const RowTracksSection = ({ title, id }) => {
  const [state, setState] = useState({
    playListTrack: [
      {
        id: 0,
        title: "",
        artist: "",
        album: "",
        cover:
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
        duration: 0,
      },
    ],
    isLoading: true,
  });

  useEffect(() => {
    const tracks = async () => {
      const result = await Api.get("/playlists/" + id);
      let data = result.data.tracks.data;
      data = data.slice(0, 10);

      data = data.map((track) => {
        return {
          id: track.id,
          title: track.title,
          artist: { id: track.artist.id, name: track.artist.name },
          album: { id: track.album.id, title: track.album.title },
          cover: track.album.cover_medium,
          duration: track.duration,
          preview: track.preview,
        };
      });
      setState({
        ...state,
        playListTrack: data,
        isLoading: false,
      });
    };
    tracks();
  }, [state.isLoading]);

  return (
    <>
      <RowTitle>{title}</RowTitle>
      <Swiper
        spaceBetween={15}
        slidesPerView={2.5}
        breakpoints={{ 550: { slidesPerView: 3, spaceBetween: 0 } }}
      >
        {state.playListTrack.map((track) => (
          <SwiperSlide key={track.id}>
            <TrackCard className="apparition" id={track.id} data={track} />
          </SwiperSlide>
        ))}
      </Swiper>
    </>
  );
};

export default RowTracksSection;
